# Overview
This mod add MegaBuster as a craftable weapons on MUCK!
Megabuster have the original megaman SFX.

# Instructions for install:
place the dll in your plugins folder or extract to a folder inside plugins.

#About the mod:
-For crafting the megabuster you need 1 Gold Bar, 1 Iron Bar and 1 Mithril Bar.
-Like the Bows on this game YOU NEED to equip an arrow to shoot.
-Damage scales with the arrow equipped.
-MegaBuster does not consume the arrow equipped.


# Screenshots
![](https://i.imgur.com/hkDs1DQ.jpg)
![](https://i.imgur.com/0TbqLjA.png)
![](https://i.imgur.com/yTcUuce.png)
![](https://i.imgur.com/7D0p2SA.png)


# Feedback
Hey, if you want to talk, give me a hint for this mod you can DM me on discord, but sorry for my bad english and i hope you enjoy!



# Discord
BLKNeko#8448 


# Changelog
V 1.0.0.0 Posted



# Donations
-Please, remember this mod is FREE and aways will be, i made this hoping that you would enjoy and have fun!
-If you want to support me this is the link
https://www.paypal.com/donate?hosted_button_id=JU57WD5QVUC2Y


#CREDITS
MEGABUSTER MODEL ORIGINAL CREDITS!!!
https://www.models-resource.com/xbox_360/avatarmarketplace/model/12960/
